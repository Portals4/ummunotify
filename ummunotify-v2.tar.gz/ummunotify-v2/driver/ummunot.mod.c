#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x14522340, "module_layout" },
	{ 0x4f1939c7, "per_cpu__current_task" },
	{ 0x9b388444, "get_zeroed_page" },
	{ 0xc8b57c27, "autoremove_wake_function" },
	{ 0xd691cba2, "malloc_sizes" },
	{ 0x28a4cb8c, "mmu_notifier_register" },
	{ 0x712aa29b, "_spin_lock_irqsave" },
	{ 0x343a1a8, "__list_add" },
	{ 0xfbdea30a, "__mmdrop" },
	{ 0xfbe27a1c, "rb_first" },
	{ 0xffc7c184, "__init_waitqueue_head" },
	{ 0x3acac6d7, "misc_register" },
	{ 0xecde1418, "_spin_lock_irq" },
	{ 0x83264fe4, "mmu_notifier_unregister" },
	{ 0xc0580937, "rb_erase" },
	{ 0x85f8a266, "copy_to_user" },
	{ 0x208f6781, "fasync_helper" },
	{ 0xb4390f9a, "mcount" },
	{ 0x521445b, "list_del" },
	{ 0x4b07e779, "_spin_unlock_irqrestore" },
	{ 0x78764f4e, "pv_irq_ops" },
	{ 0x1000e51, "schedule" },
	{ 0x2044fa9e, "kmem_cache_alloc_trace" },
	{ 0xa6dcc773, "rb_insert_color" },
	{ 0xe52947e7, "__phys_addr" },
	{ 0x4302d0eb, "free_pages" },
	{ 0x642e54ac, "__wake_up" },
	{ 0x37a0cba, "kfree" },
	{ 0x33d92f9a, "prepare_to_wait" },
	{ 0x3399cc18, "kill_fasync" },
	{ 0x9ccb2622, "finish_wait" },
	{ 0xbdf5c25c, "rb_next" },
	{ 0xe46d84e9, "get_page" },
	{ 0x3302b500, "copy_from_user" },
	{ 0x16c0b339, "misc_deregister" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "0BA11579DFD091475FD6B48");

static const struct rheldata _rheldata __used
__attribute__((section(".rheldata"))) = {
	.rhel_major = 6,
	.rhel_minor = 5,
};
